# ChatMind - Aplicação de Monitoramento de Chat

## 📋 Como usar:

1. **Instalar Node.js** (se não tiver):
   - Baixe em: https://nodejs.org/
   - Instale a versão LTS

2. **Instalar dependências**:
   ```bash
   npm install
   ```

3. **Executar a aplicação**:
   ```bash
   npm start
   ```

## 🎯 Funcionalidades:

- ✅ Monitoramento de chat em tempo real
- ✅ Suporte a Twitch e Kick
- ✅ Interface moderna e intuitiva
- ✅ Estatísticas do Kick
- ✅ Auto-scroll nas mensagens

## ⚙️ Configuração:

1. Abra a aplicação
2. Vá para a aba "Canais"
3. Configure os canais desejados
4. Salve as configurações

## 🆘 Suporte:

Se tiver problemas, verifique se:
- Node.js está instalado
- Todas as dependências foram instaladas
- Os canais estão configurados corretamente

---
Versão: 1.0.1
Desenvolvido por: Antonio Ma Neto
